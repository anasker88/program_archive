let circle x = x *. x *. 3.141592;;
