open TySyntax

let ty = TyFun(TyInt, TyInt)
let () =
  print_type ty;
  print_endline ""
