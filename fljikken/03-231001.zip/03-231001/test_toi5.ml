let a = [[true;false];[true;false]]
let b = [[true;true];[true;false]]
BoolMatrix.add_mat a b
BoolMatrix.mul a b
BoolMatrix.mul b a
