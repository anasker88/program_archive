nat(z).
nat(s(X)) :- nat(X).
