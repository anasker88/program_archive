sub(X,z,X).
sub(s(X),s(Y), Z) :-sub(X,Y,Z).
