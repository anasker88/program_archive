test :- q(X, X).
q(X, f(X)).